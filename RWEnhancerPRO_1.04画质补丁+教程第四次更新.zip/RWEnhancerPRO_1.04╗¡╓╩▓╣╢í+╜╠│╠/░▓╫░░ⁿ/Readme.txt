RW Enhancer PRO version 1.04 (c)2014-2023 Lonely Bits Games

-----------------
HELP/SUPPORT
-----------------

https://www.rwcentral.com/support

-----------------
LEGAL NOTICE
----------------- 

This is user generated content designed for use with Dovetail Games Software.

Dovetail Games does not approve or endorse this user generated content and does not accept any liability or responsibility regarding it.

This user generated content has not been screened or tested by Dovetail Games.  Accordingly, it may adversely affect your use of Dovetail Games products.  If you install this user generated content and it infringes the rules regarding user-generated content, Dovetail Games may choose to discontinue any support for that product which they may otherwise have provided.

The Dovetail Games EULA sets out in detail how user generated content may be used, which you can review further here: www.dovetailgames.com/terms. In particular, this user generated content includes work which remains the intellectual property of Dovetail Games and which may not be rented, leased, sub-licensed, modified, adapted, copied, reproduced or redistributed without the permission of Dovetail Games.